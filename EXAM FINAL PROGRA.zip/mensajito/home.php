<?php 
	session_start();
	if(isset($_SESSION['name']))
	{
		include "layouts/header4.php"; 
		include "config.php"; 
		
		$sql="SELECT * FROM `chat`";

		$query = mysqli_query($conn,$sql);
?>
<style>
  h2{
color: #000000ff;
  }
  label{
color:white;
  }
  span{
	  color: #f40202ff;
	  font-weight:bold;
  }
  
  .btn-primary {
    background-color: #b73a3aff;
	}
	.display-chat{
		height:300px;
		background-color:#d69de0;
		margin-bottom:4%;
		overflow:auto;
		padding:15px;
	}
	.message{
		background-color: #f823bf9c;
		color: white;
		border-radius: 5px;
		padding: 5px;
		margin-bottom: 3%;
	}
  </style>

<div class="container">
	<br>
	<br>
	<br>
	<br>
	<br>
  <center><h2 style="font-family: 'Broadway', times , serif">Bienvenid@ <span style="color: #d23418ff;"><?php echo $_SESSION['name']; ?> !</span></h2>
  <br><br>
	<h3><label style="font-family: 'Times new roma', times , serif"><span style="color: #000000ff;">empieza tu propia historia con cada palabra</label></h3><br>
	<br><br>
	<a href="chatpage.php" class="btn btn-primary">Abrir chat</a>
  
</div>

</body>
</html>
<?php
	}
	else
	{
		header('location:index.php');
	}
?>