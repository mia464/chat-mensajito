<?php include "layouts/header.php"; ?>
<div class="container">
<br>
<br>
<br>
<br>
<br>
<br>

<center><h2 style="font-family: 'Broadway',times,serif"><span style="color: #fb8958f0;"> Mensajito </h2></center>
<h3 style="font-family: 'Broadway',times,serif"> Hola!!. Es un gusto tenerte aqui con nosotros, mensajito tu mejor amigo chat </h3>
<center><img src="images/favicon.ico" width="180" height="120"></a></center>
</div>

</body>
</html>
