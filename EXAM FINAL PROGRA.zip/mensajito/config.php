<?php

$dbHost ='localhost';
$dbUsername ='root';
$dbPassword ='';
$dbDatabase ='mensajito';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);

?>